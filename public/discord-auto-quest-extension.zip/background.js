chrome.runtime.onInstalled.addListener(() => {
  console.info('Discord Auto Quest extension installed');
});

// ---------- Achievement quest helper: cross-origin discordsays.com fetch ----------
// The page cannot set Referer/Origin/User-Agent on fetch (forbidden headers),
// so a dynamic declarativeNetRequest rule rewrites them for this one request.
const DS_RULE_ID = 9001;
const DS_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9236 Chrome/138.0.7204.251 Electron/37.6.0 Safari/537.36';

async function dsFetch(request, sendResponse) {
  const { url, headers, body, referer } = request;
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [DS_RULE_ID],
      addRules: [{
        id: DS_RULE_ID,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [
            { header: 'Referer', operation: 'set', value: referer },
            { header: 'Origin', operation: 'remove' },
            { header: 'User-Agent', operation: 'set', value: DS_UA }
          ]
        },
        condition: {
          urlFilter: '||discordsays.com/',
          resourceTypes: ['xmlhttprequest']
        }
      }]
    });

    const res = await fetch(url, {
      method: 'POST',
      headers: headers || {},
      body: body ? JSON.stringify(body) : undefined
    });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch (e) { /* not json */ }
    sendResponse({ ok: res.ok, status: res.status, body: json });
  } catch (error) {
    sendResponse({ ok: false, status: 0, error: String(error) });
  } finally {
    chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [DS_RULE_ID] }).catch(() => {});
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getVersion') {
    const manifest = chrome.runtime.getManifest();
    sendResponse({ version: manifest.version });
    return false;
  } else if (request.action === 'dsFetch') {
    dsFetch(request, sendResponse);
    return true; // async response
  } else if (request.action === 'executeQuestCode') {
    if (sender.tab && sender.tab.id) {
      const manifest = chrome.runtime.getManifest();
      chrome.scripting.executeScript({
        target: { tabId: sender.tab.id },
        func: (version) => { window.__QUEST_VERSION = version; },
        args: [manifest.version],
        world: 'MAIN'
      }).then(() => {
        return chrome.scripting.executeScript({
          target: { tabId: sender.tab.id },
          files: ['quest-code.js'],
          world: 'MAIN'
        });
      }).then(() => {
        sendResponse({ success: true });
      }).catch((error) => {
        console.error('Error injecting quest code:', error);
        sendResponse({ success: false, error: error.message });
      });
      return true;
    } else {
      sendResponse({ success: false, error: 'No tab ID found' });
      return false;
    }
  }
});
