(function() {
  'use strict';

  // ===== CREDITS (sửa link ở đây) =====
  const CREDITS = {
    youtube: { name: 'YouTube', sub: '@kandakashiko', url: 'https://youtube.com/@kandakashiko' },
    discord: { name: 'Discord', sub: 'KDGW', url: 'https://discord.gg/7ERYA9ArWH' }
  };

  const questStateCache = new Map();
  let isRunning = false;
  let hasRunOnce = false;
  let bubble = null;
  let panel = null;
  let isDragging = false;
  let isLongPress = false;
  let longPressTimer = null;
  let startPos = { x: 0, y: 0 };

  // ---------- Styles (KTool design language) ----------
  const STYLE = `    #dqa-bubble, #dqa-panel, #dqa-bubble *, #dqa-panel * { box-sizing: border-box; }

    #dqa-bubble {
      position: fixed;
      bottom: calc(88px + env(safe-area-inset-bottom, 0px));
      right: calc(18px + env(safe-area-inset-right, 0px));
      width: 54px; height: 54px;
      z-index: 999999;
      cursor: pointer; user-select: none; -webkit-user-select: none;
      touch-action: none;
      transition: transform .2s ease;
      -webkit-tap-highlight-color: transparent;
      animation: dqaBubbleIn .5s cubic-bezier(.34,1.56,.64,1);
    }
    #dqa-bubble:active { transform: scale(.92); }
    @keyframes dqaBubbleIn {
      0% { transform: scale(0) rotate(-40deg); opacity: 0; }
      60% { transform: scale(1.15) rotate(6deg); opacity: 1; }
      100% { transform: scale(1) rotate(0); opacity: 1; }
    }
    /* no glow ring: running state is shown only by the green LED dot + badge */
    .dqa-bub-core {
      position: absolute; inset: 0;
      border: none;
      background: transparent;
      display: flex; align-items: center; justify-content: center;
      color: #fff;
    }
    .dqa-avt-img { width: 100%; height: 100%; border-radius: 16px; object-fit: cover; display: block; }
    .dqa-led {
      position: absolute; right: -3px; bottom: -3px;
      width: 13px; height: 13px; border-radius: 50%;
      background: #3f3f46;
      border: 3px solid #0e0e11;
      transition: background .3s ease;
      pointer-events: none;
    }
    #dqa-bubble.running .dqa-led {
      background: #4ade80;
      animation: dqaLedPulse 1.4s ease-in-out infinite;
    }
    @keyframes dqaLedPulse {
      0%,100% { box-shadow: 0 0 0 0 rgba(74,222,128,.5); }
      50% { box-shadow: 0 0 0 5px rgba(74,222,128,0); }
    }
    .dqa-badge {
      position: absolute; top: -7px; left: 50%; transform: translateX(-50%);
      min-width: 30px; height: 17px;
      background: linear-gradient(135deg, #6366f1, #a855f7);
      color: #fff;
      font: 700 10px/17px -apple-system, 'Segoe UI', sans-serif;
      text-align: center; border-radius: 999px;
      padding: 0 6px; display: none;
      border: 2px solid #0e0e11;
      pointer-events: none;
    }
    .dqa-badge.show { display: block; }

    /* ---------- Panel ---------- */
    #dqa-panel {
      position: fixed;
      bottom: calc(156px + env(safe-area-inset-bottom, 0px));
      right: calc(18px + env(safe-area-inset-right, 0px));
      width: 300px;
      max-width: calc(100vw - 24px);
      background: rgba(14,14,18,.94);
      border: none;
      border-radius: 18px;
      box-shadow: 0 18px 50px rgba(0,0,0,.6);
      backdrop-filter: blur(24px);
      -webkit-backdrop-filter: blur(24px);
      z-index: 999998;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Inter', system-ui, sans-serif;
      color: #e4e4e7;
      overflow: hidden;
      transform: scale(.9) translateY(12px);
      opacity: 0;
      pointer-events: none;
      transition: transform .26s cubic-bezier(.34,1.4,.44,1), opacity .2s ease;
    }
    #dqa-panel.show {
      transform: scale(1) translateY(0);
      opacity: 1;
      pointer-events: auto;
    }
    #dqa-panel::before {
      content: ""; position: absolute; top: 0; left: 0; right: 0; height: 2px;
      background: linear-gradient(90deg, #6366f1, #a855f7 50%, #ec4899);
      z-index: 2;
    }


    .dqa-body { padding: 14px 14px 4px; }

    .dqa-quests {
      max-height: 216px;
      overflow-y: auto;
      margin-bottom: 10px;
      display: flex; flex-direction: column; gap: 7px;
      padding-right: 2px;
    }
    .dqa-quests::-webkit-scrollbar { width: 3px; }
    .dqa-quests::-webkit-scrollbar-thumb { background: #2a2a32; border-radius: 3px; }

    .dqa-quest {
      display: flex; align-items: center; gap: 10px;
      padding: 10px 12px;
      background: linear-gradient(135deg, #14141a, #17171d);
      border: 1px solid #22222b;
      border-radius: 12px;
    }
    @media (hover:hover) { .dqa-quest:hover { border-color: #2e2e3a; } }
    .dqa-quest.completed { border-color: rgba(74,222,128,.25); }

    .dqa-quest-info { flex: 1; min-width: 0; }
    .dqa-quest-name-row {
      display: flex; align-items: center; gap: 8px;
      margin-bottom: 7px;
    }
    .dqa-quest-name {
      flex: 1; min-width: 0;
      font-size: 12px; font-weight: 600; color: #e4e4e7;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .dqa-kind {
      flex-shrink: 0;
      font-size: 8px; font-weight: 700; letter-spacing: .8px; text-transform: uppercase;
      padding: 3px 7px; border-radius: 999px;
    }
    .dqa-kind.video { color: #c4b5fd; background: rgba(139,92,246,.16); }
    .dqa-kind.game { color: #93c5fd; background: rgba(59,130,246,.14); }
    .dqa-quest-progress {
      height: 4px;
      background: #22222b;
      border-radius: 2px;
      overflow: hidden;
    }
    .dqa-quest-fill {
      height: 100%; width: 0%;
      background: linear-gradient(90deg, #6366f1, #a855f7);
      border-radius: 2px;
      transition: width .45s cubic-bezier(.4,0,.2,1);
    }
    .dqa-quest.completed .dqa-quest-fill { background: linear-gradient(90deg, #22c55e, #4ade80); }

    .dqa-quest-pct {
      flex-shrink: 0;
      min-width: 48px; text-align: right;
      font-size: 15px; font-weight: 700;
      font-variant-numeric: tabular-nums;
      color: #e4e4e7;
      display: flex; align-items: center; justify-content: flex-end; gap: 1px;
    }
    .dqa-quest-pct svg { width: 17px; height: 17px; }
    .dqa-quest-pct i { font-style: normal; font-size: 10px; opacity: .55; margin-left: 1px; }
    .dqa-quest.completed .dqa-quest-pct { color: #4ade80; }

    .dqa-empty { text-align: center; padding: 22px 12px; color: #52525b; }
    .dqa-empty p { margin: 8px 0 0; font-size: 12px; }

    /* ---------- Start button ---------- */
    .dqa-start {
      width: 100%;
      padding: 11px 0;
      margin-bottom: 12px;
      background: linear-gradient(135deg, #6366f1, #a855f7);
      border: none;
      border-radius: 12px;
      color: #fff;
      font: 700 13px -apple-system, 'Segoe UI', sans-serif;
      letter-spacing: .3px;
      cursor: pointer;
      min-height: 40px;
      transition: transform .15s ease, box-shadow .2s ease, opacity .2s ease;
      box-shadow: 0 4px 14px rgba(99,102,241,.3);
      position: relative;
      overflow: hidden;
    }
    .dqa-start::after {
      content: ""; position: absolute; inset: 0;
      background: linear-gradient(100deg, transparent 30%, rgba(255,255,255,.22) 50%, transparent 70%);
      transform: translateX(-100%);
      animation: dqaShine 3.2s 1s ease-in-out infinite;
    }
    .dqa-start:disabled::after { animation: none; opacity: 0; }
    @keyframes dqaShine {
      0%, 55% { transform: translateX(-100%); }
      85%, 100% { transform: translateX(100%); }
    }
    @media (hover:hover) {
      .dqa-start:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 6px 18px rgba(99,102,241,.45); }
    }
    .dqa-start:active:not(:disabled) { transform: scale(.97); }
    .dqa-start:disabled {
      background: #1c1c22;
      color: #52525b;
      cursor: default;
      box-shadow: none;
    }
    .dqa-start.hidden { display: none; }

    /* ---------- Credits footer ---------- */
    .dqa-foot {
      padding: 11px 14px 13px;
      border-top: 1px solid #1e1e25;
    }
    .dqa-foot-links { display: none; gap: 7px; }
    #dqa-panel.running .dqa-foot-links { display: flex; }
    .dqa-foot-note {
      margin-top: 9px; text-align: center;
      font-size: 9px; font-weight: 500; color: #52525b;
      letter-spacing: .2px;
    }
    .dqa-link {
      flex: 1; display: flex; align-items: center; gap: 8px;
      padding: 8px 10px;
      background: #131318;
      border: 1px solid #22222b;
      border-radius: 11px;
      text-decoration: none;
      transition: border-color .2s ease, background .2s ease;
      -webkit-tap-highlight-color: transparent;
    }
    @media (hover:hover) {
      .dqa-link:hover { border-color: #2e2e3a; background: #17171d; }
    }
    .dqa-link:active { transform: scale(.97); }
    .dqa-link-ico {
      width: 24px; height: 24px; border-radius: 7px;
      display: flex; align-items: center; justify-content: center;
      color: #fff; flex-shrink: 0;
    }
    .dqa-link-ico.yt { background: linear-gradient(135deg, #ef4444, #dc2626); }
    .dqa-link-ico.dc { background: linear-gradient(135deg, #5865f2, #4f46e5); }
    .dqa-link-info { min-width: 0; }
    .dqa-link-name {
      font-size: 10.5px; font-weight: 700; color: #e4e4e7;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .dqa-link-sub {
      font-size: 9px; color: #52525b; font-weight: 500;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }

    /* ---------- Mobile ---------- */
    @media (max-width:600px), (pointer:coarse) {
      #dqa-bubble {
        width: 50px; height: 50px;
        bottom: calc(74px + env(safe-area-inset-bottom, 0px));
        right: calc(14px + env(safe-area-inset-right, 0px));
      }
      .dqa-bub-core { border-radius: 15px; }
      #dqa-panel {
        width: min(300px, calc(100vw - 28px));
        right: 12px;
        bottom: calc(132px + env(safe-area-inset-bottom, 0px));
        backdrop-filter: none;
        -webkit-backdrop-filter: none;
      }
      .dqa-quests { max-height: 24vh; -webkit-overflow-scrolling: touch; }
    }
  `;

  const SVG_DC_LOGO = `<svg viewBox="0 0 24 24" fill="currentColor" width="28" height="28"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>`;
  const SVG_DC_SM = `<svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>`;
  const SVG_CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" width="14" height="14"><path d="M20 6L9 17l-5-5"/></svg>';
  const SVG_YT = '<svg viewBox="0 0 24 24" fill="currentColor" width="13" height="13"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>';
  const SVG_DC = '<svg viewBox="0 0 24 24" fill="currentColor" width="13" height="13"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>';

  // ---------- UI creation ----------
  function ensureUI() {
    if (document.getElementById('dqa-bubble')) return false;
    if (!document.body) return false;

    const style = document.createElement('style');
    style.textContent = STYLE;
    document.head.appendChild(style);

    // Bubble
    bubble = document.createElement('div');
    bubble.id = 'dqa-bubble';
    bubble.innerHTML = `
      <div class="dqa-bub-core"><img class="dqa-avt-img" src="${chrome.runtime.getURL('icons/icon128.png')}" alt="Discord Auto Quest"></div>
      <span class="dqa-led"></span>
      <span class="dqa-badge" id="dqa-badge">0</span>
    `;
    document.body.appendChild(bubble);

    bubble.addEventListener('click', onBubbleClick);
    bubble.addEventListener('touchstart', onTouchStart, { passive: true });

    // Panel
    panel = document.createElement('div');
    panel.id = 'dqa-panel';
    panel.innerHTML = `
      <div class="dqa-body">
        <button class="dqa-start" id="dqa-start">▶ Bắt đầu</button>
        <div class="dqa-quests" id="dqa-quests">
          <div class="dqa-empty">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="40" height="40" opacity=".4"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/></svg>
            <p>Chưa có quest nào đang chạy</p>
          </div>
        </div>
      </div>
      <div class="dqa-foot">
        <div class="dqa-foot-links">
        <a class="dqa-link" href="${CREDITS.youtube.url}" target="_blank" rel="noopener noreferrer">
          <div class="dqa-link-ico yt">${SVG_YT}</div>
          <div class="dqa-link-info">
            <div class="dqa-link-name">${CREDITS.youtube.name}</div>
            <div class="dqa-link-sub">${CREDITS.youtube.sub}</div>
          </div>
        </a>
        <a class="dqa-link" href="${CREDITS.discord.url}" target="_blank" rel="noopener noreferrer">
          <div class="dqa-link-ico dc">${SVG_DC}</div>
          <div class="dqa-link-info">
            <div class="dqa-link-name">${CREDITS.discord.name}</div>
            <div class="dqa-link-sub">${CREDITS.discord.sub}</div>
          </div>
        </a>
        </div>
        <div class="dqa-foot-note">Tham gia cộng đồng để biết thêm</div>
      </div>
    `;
    document.body.appendChild(panel);

    document.getElementById('dqa-start').addEventListener('click', () => {
      if (!isRunning) startQuest();
    });
    window.addEventListener('resize', () => {
      if (panel && panel.classList.contains('show')) positionPanel();
    });
    // Panel height changes while quests render (open / start / done / links) -
    // watch its size and re-stick it to the bubble so it never overlaps the bubble.
    if (window.ResizeObserver && panel) {
      new ResizeObserver(() => {
        if (panel.classList.contains('show')) positionPanel();
      }).observe(panel);
    }

    console.info('[DQA] UI injected on', location.href);
    return true;
  }

  // Create UI (bubble) when arriving on quest-home. Panel only opens on tap.
  function activateUI() {
    ensureUI();
  }

  // Position panel relative to the bubble, flipping to stay on screen
  function positionPanel(rect) {
    if (!bubble || !panel) return;
    const r = rect || bubble.getBoundingClientRect();
    const pw = panel.offsetWidth || 300;
    const ph = panel.offsetHeight || 400;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const gap = 14;
    const margin = 10;

    // Horizontal: align with bubble, keep inside screen
    let left = (r.left + r.width / 2 > vw / 2) ? (r.right - pw) : r.left;
    left = Math.max(margin, Math.min(vw - pw - margin, left));

    // Vertical: prefer above the bubble, flip below if no room
    let top = r.top - ph - gap;
    if (top < margin) {
      top = r.bottom + gap;
      if (top + ph > vh - margin) top = Math.max(margin, vh - ph - margin);
    }
    if (top + ph > vh - margin) top = Math.max(margin, vh - ph - margin);

    panel.style.left = left + 'px';
    panel.style.top = top + 'px';
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
  }

  // ---------- Bubble interaction: tap = toggle panel ----------
  // On touch devices the browser fires BOTH touchend and a synthetic click.
  // Handling both double-toggles the panel (looks like "tap does nothing").
  // -> touch path toggles + stamps the time; the click path ignores clicks
  //    arriving right after a touch toggle.
  let lastTouchToggleAt = 0;

  function togglePanel() {
    ensureUI();
    if (panel.classList.contains('show')) {
      panel.classList.remove('show');
    } else {
      positionPanel();
      panel.classList.add('show');
    }
  }

  function onBubbleClick() {
    if (isDragging || isLongPress) { isDragging = false; isLongPress = false; return; }
    if (Date.now() - lastTouchToggleAt < 600) return; // synthetic click after touch
    togglePanel();
  }

  let dragRect = null;
  let dragVW = 0, dragVH = 0;
  let dragAccX = 0, dragAccY = 0, dragRafId = 0;

  function onTouchStart(e) {
    const touch = e.touches[0];
    startPos = { x: touch.clientX, y: touch.clientY };
    isDragging = false;
    isLongPress = false;

    longPressTimer = setTimeout(() => { isLongPress = true; bubble.style.transition = 'none'; }, 300);

    document.addEventListener('touchmove', onTouchMove, { passive: false });
    document.addEventListener('touchend', onTouchEnd);
  }

  function onTouchMove(e) {
    if (!isLongPress) return;
    e.preventDefault();
    const touch = e.touches[0];
    const dx = touch.clientX - startPos.x;
    const dy = touch.clientY - startPos.y;
    startPos = { x: touch.clientX, y: touch.clientY };

    if (!isDragging) {
      if (Math.abs(dx) < 10 && Math.abs(dy) < 10) return;
      isDragging = true;
      clearTimeout(longPressTimer);
      // Cache rect + viewport ONCE per drag. Reading layout per touchmove is what made dragging laggy.
      const r = bubble.getBoundingClientRect();
      dragRect = { left: r.left, top: r.top, right: r.right, bottom: r.bottom, width: r.width, height: r.height };
      dragVW = window.innerWidth;
      dragVH = window.innerHeight;
      bubble.style.willChange = 'left, top';
    }

    dragAccX += dx; dragAccY += dy;
    if (!dragRafId) dragRafId = requestAnimationFrame(applyDragFrame);
  }

  // Coalesce touchmove bursts into ONE style write per frame -> smooth 60fps drag.
  function applyDragFrame() {
    dragRafId = 0;
    if (!isDragging || !dragRect) return;
    const dx = dragAccX; dragAccX = 0;
    const dy = dragAccY; dragAccY = 0;
    dragRect.left = Math.max(4, Math.min(dragVW - 60, dragRect.left + dx));
    dragRect.top = Math.max(4, Math.min(dragVH - 60, dragRect.top + dy));
    dragRect.right = dragRect.left + dragRect.width;
    dragRect.bottom = dragRect.top + dragRect.height;
    bubble.style.left = dragRect.left + 'px';
    bubble.style.top = dragRect.top + 'px';
    bubble.style.right = 'auto';
    bubble.style.bottom = 'auto';
    if (panel && panel.classList.contains('show')) positionPanel(dragRect);
  }

  // After dragging, glide the bubble back to the nearest screen edge
  // so it never floats free in the middle of the screen.
  function snapBubbleToEdge() {
    if (!bubble) return;
    const r = bubble.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const margin = 8;
    const leftDist = r.left + r.width / 2;          // distance of center to left edge
    const rightDist = vw - (r.left + r.width / 2); // distance of center to right edge
    const left = leftDist <= rightDist ? margin : vw - r.width - margin;
    const top = Math.max(margin, Math.min(vh - r.height - margin, r.top));

    bubble.style.transition = 'left .3s cubic-bezier(.22,1,.36,1), top .3s cubic-bezier(.22,1,.36,1), transform .2s ease';
    bubble.style.left = left + 'px';
    bubble.style.top = top + 'px';
    bubble.style.right = 'auto';
    bubble.style.bottom = 'auto';
    setTimeout(() => { if (bubble) bubble.style.transition = 'transform .2s ease'; }, 350);

    if (panel && panel.classList.contains('show')) {
      positionPanel({ left, top, right: left + r.width, bottom: top + r.height, width: r.width, height: r.height });
    }
  }

  function onTouchEnd() {
    document.removeEventListener('touchmove', onTouchMove);
    document.removeEventListener('touchend', onTouchEnd);
    if (dragRafId) { cancelAnimationFrame(dragRafId); dragRafId = 0; }
    bubble.style.willChange = '';
    if (!isLongPress) {
      lastTouchToggleAt = Date.now();
      if (isDragging) { isDragging = false; snapBubbleToEdge(); return; } // moved finger = not a tap
      togglePanel();
      return;
    }
    if (isDragging) snapBubbleToEdge();
    else isLongPress = false;
    isDragging = false;
  }

  function closePanel() {
    panel?.classList.remove('show');
  }

  // ---------- Quest control ----------
  function startQuest() {
    if (isRunning) return;
    isRunning = true;
    hasRunOnce = true;
    renderRunning(true);
    setStatus('Đang quét & chạy quest...', 'running');

    if (typeof chrome !== 'undefined' && chrome.runtime?.id) {
      try {
        chrome.runtime.sendMessage({ action: 'executeQuestCode' }, () => {
          if (chrome.runtime.lastError) {
            isRunning = false;
            renderRunning(false);
            setStatus('Lỗi khi chạy — thử lại', '');
          }
        });
      } catch (e) {
        isRunning = false;
        renderRunning(false);
      }
    }
  }

  function renderRunning(running) {
    bubble?.classList.toggle('running', running);
    panel?.classList.toggle('running', running);
    document.getElementById('dqa-chip')?.classList.toggle('running', running);
    const btn = document.getElementById('dqa-start');
    if (btn) {
      btn.disabled = running;
      btn.classList.toggle('hidden', running);
      btn.textContent = running ? '' : '▶ ' + (hasRunOnce ? 'Chạy lại' : 'Bắt đầu');
    }
  }

  function setStatus(text, mode) {
    const el = document.getElementById('dqa-status-text');
    const chip = document.getElementById('dqa-chip');
    if (el) el.textContent = text;
    if (chip) {
      chip.classList.toggle('running', mode === 'running');
      chip.classList.toggle('done', mode === 'done');
    }
  }

  // ---------- Quest list rendering ----------
  function updateQuests() {
    const container = document.getElementById('dqa-quests');
    const badge = document.getElementById('dqa-badge');
    if (!container) return;

    const quests = Array.from(questStateCache.values());
    const activeCount = quests.filter(q => !q.completed).length;

    if (badge) {
      badge.textContent = activeCount;
      badge.classList.toggle('show', activeCount > 0);
    }

    if (quests.length === 0) {
      container.innerHTML = `
        <div class="dqa-empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="40" height="40" opacity=".4"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/></svg>
          <p>${isRunning ? 'Đang quét quest...' : 'Không có quest nào'}</p>
        </div>`;
      return;
    }

    container.innerHTML = quests.map(q => {
      const target = q.target || 1;
      const pct = Math.min(100, Math.round((q.progress / target) * 100));
      return `
        <div class="dqa-quest ${q.completed ? 'completed' : ''}">
          <div class="dqa-quest-info">
            <div class="dqa-quest-name-row">
              <div class="dqa-quest-name">${q.name}</div>
              <span class="dqa-kind ${q.kind === 'video' ? 'video' : 'game'}">${q.kind === 'video' ? 'Video' : 'Game'}</span>
            </div>
            <div class="dqa-quest-progress"><div class="dqa-quest-fill" style="width:${pct}%"></div></div>
          </div>
          <div class="dqa-quest-pct">${q.completed ? SVG_CHECK : pct + '<i>%</i>'}</div>
        </div>`;
    }).join('');
  }

  // ---------- Messages from quest-code ----------
  window.addEventListener('message', ({ source, data }) => {
    if (source !== window || !data || data.prefix !== 'DISCORD_QUEST_COMPLETER') return;

    if (data.type === 'DS_FETCH') {
      // Cross-origin discordsays.com call -> background service worker
      try {
        chrome.runtime.sendMessage(
          { action: 'dsFetch', url: data.url, headers: data.headers, body: data.body, referer: data.referer },
          (resp) => {
            window.postMessage({
              prefix: 'DISCORD_QUEST_COMPLETER',
              dir: 'to-quest',
              type: 'DS_FETCH_RESULT',
              requestId: data.requestId,
              data: resp || { ok: false, status: 0, error: 'no-response' }
            }, '*');
          }
        );
      } catch (e) {
        window.postMessage({
          prefix: 'DISCORD_QUEST_COMPLETER',
          dir: 'to-quest',
          type: 'DS_FETCH_RESULT',
          requestId: data.requestId,
          data: { ok: false, status: 0, error: String(e) }
        }, '*');
      }
      return;
    }

    if (data.type === 'QUEST_LIST') {
      questStateCache.clear();
      data.data.forEach(q => questStateCache.set(q.id, q));
      updateQuests();
    } else if (data.type === 'QUEST_UPDATE') {
      const had = questStateCache.get(data.data.id);
      if (had && !had.completed && data.data.completed) {
      }
      questStateCache.set(data.data.id, Object.assign({}, had || {}, data.data));
      updateQuests();
    } else if (data.type === 'QUEST_ALL_DONE') {
      isRunning = false;
      hasRunOnce = true;
      renderRunning(false);
      const quests = Array.from(questStateCache.values());
      if (quests.length === 0) {
        setStatus('Không có quest nào đang hoạt động', '');
      } else if (quests.every(q => q.completed)) {
        setStatus('Hoàn tất tất cả quests 🎉', 'done');
      } else {
        setStatus('Đã chạy xong vòng quét', '');
      }
    }
  });

  // ---------- Init: ONLY on /quest-home ----------
  function isQuestHome() {
    return location.pathname.includes('/quest-home');
  }

  function teardownUI() {
    bubble?.remove(); panel?.remove();
    bubble = null; panel = null;
    isRunning = false;
    questStateCache.clear();
  }

  // Wait until Discord has FULLY loaded before showing any UI:
  // document complete + #app-mount has rendered children + small settle delay.
  // Prevents injecting UI mid-load (blank panel / wrong layout / errors).
  let pageReadyToken = 0;
  function whenPageReady(cb) {
    const myToken = ++pageReadyToken;
    let settled = false;
    const finish = () => {
      if (settled || myToken !== pageReadyToken) return;
      settled = true;
      if (isQuestHome()) cb();
    };
    const step = () => {
      if (settled || myToken !== pageReadyToken) return;
      const mount = document.getElementById('app-mount');
      if (document.readyState === 'complete' && mount && mount.childElementCount > 0) {
        setTimeout(finish, 900); // let the SPA settle a beat after paint
      } else {
        setTimeout(step, 300);
      }
    };
    step();
    setTimeout(finish, 15000); // hard fallback
  }

  function init() {
    if (isQuestHome()) whenPageReady(activateUI);

    let lastUrl = location.href;
    new MutationObserver(() => {
      if (location.href !== lastUrl) {
        lastUrl = location.href;
        if (isQuestHome()) whenPageReady(activateUI);
        else teardownUI();
      }
    }).observe(document.documentElement, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
