(function() {
  'use strict';

  // Ported from discord-quest-auto source (questWorker.ts / aiko-style):
  // - Video quest (WATCH_VIDEO / WATCH_VIDEO_ON_MOBILE): video-progress loop, speed=6, interval=6s, maxFuture=10
  // - Game quest (PLAY_ON_DESKTOP / PLAY_ON_XBOX / PLAY_ON_PLAYSTATION): heartbeat {application_id, terminal} every 15s
  // - Activity quest (PLAY_ACTIVITY): heartbeat {stream_key: "call:1:1", terminal} every 15s
  // - Achievement quest (ACHIEVEMENT_IN_ACTIVITY): OAuth2 authorize -> proxy ticket -> Discord Says API
  // - All quests run in parallel (Promise.allSettled)
  // - STREAM_ON_DESKTOP: skipped (doesn't work reliably)

  const QUEST_TYPES = [
    "WATCH_VIDEO",
    "WATCH_VIDEO_ON_MOBILE",
    "PLAY_ON_DESKTOP",
    "PLAY_ON_XBOX",
    "PLAY_ON_PLAYSTATION",
    "PLAY_ACTIVITY",
    "ACHIEVEMENT_IN_ACTIVITY"
  ];
  const HEARTBEAT_INTERVAL = 15; // seconds (Discord accepts 15s heartbeats)

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ---------- Webpack access (unchanged) ----------
  function waitForWebpack(callback) {
    const checkInterval = 100;
    const maxAttempts = 100;
    let attempts = 0;

    const check = () => {
      if (attempts >= maxAttempts) return;

      if (typeof window.webpackChunkdiscord_app === 'undefined') {
        attempts++;
        setTimeout(check, checkInterval);
        return;
      }

      try {
        const originalJQuery = window.$;
        delete window.$;

        const webpackRequire = window.webpackChunkdiscord_app.push([[Symbol()], {}, (require) => require]);
        window.webpackChunkdiscord_app.pop();

        if (originalJQuery) window.$ = originalJQuery;

        if (!webpackRequire || !webpackRequire.c || Object.keys(webpackRequire.c).length < 10) {
          attempts++;
          setTimeout(check, checkInterval);
          return;
        }

        callback(webpackRequire);
      } catch (error) {
        attempts++;
        setTimeout(check, checkInterval);
      }
    };

    check();
  }

  function findModule(webpackRequire, filter) {
    for (const module of Object.values(webpackRequire.c)) {
      if (module?.exports) {
        const exports = module.exports;
        if (exports.A && filter(exports.A)) return exports.A;
        if (exports.Ay && filter(exports.Ay)) return exports.Ay;
        if (exports.ZP && filter(exports.ZP)) return exports.ZP;
        if (filter(exports)) return exports;
      }
    }
    return null;
  }

  function sendUpdate(type, data) {
    window.postMessage({
      prefix: 'DISCORD_QUEST_COMPLETER',
      dir: 'to-content',
      type: type,
      data: data
    }, '*');
  }

  // ---------- Bridge to background (for cross-origin discordsays.com calls) ----------
  const pendingDS = new Map();
  let dsCounter = 0;

  window.addEventListener('message', (e) => {
    const d = e.data;
    if (!d || d.prefix !== 'DISCORD_QUEST_COMPLETER' || d.dir !== 'to-quest') return;
    if (d.type === 'DS_FETCH_RESULT') {
      const cb = pendingDS.get(d.requestId);
      if (cb) { pendingDS.delete(d.requestId); cb(d.data); }
    }
  });

  function dsFetch(url, headers, body, referer) {
    return new Promise((resolve) => {
      const requestId = 'ds_' + (++dsCounter) + '_' + Date.now();
      pendingDS.set(requestId, resolve);
      window.postMessage({
        prefix: 'DISCORD_QUEST_COMPLETER',
        dir: 'to-content',
        type: 'DS_FETCH',
        requestId: requestId,
        url: url,
        headers: headers,
        body: body,
        referer: referer
      }, '*');
      setTimeout(() => {
        if (pendingDS.has(requestId)) {
          pendingDS.delete(requestId);
          resolve({ ok: false, status: 0, error: 'timeout' });
        }
      }, 30000);
    });
  }

  // ---------- Quest helpers (ported from discord.ts / questWorker.ts) ----------
  function getTaskMap(quest) {
    const taskConfig = quest.config?.taskConfig ?? quest.config?.taskConfigV2;
    return taskConfig?.tasks ?? null;
  }

  function getQuestType(quest) {
    const taskMap = getTaskMap(quest);
    if (!taskMap) return "UNKNOWN";
    for (const t of QUEST_TYPES) {
      if (taskMap[t] != null) return t;
    }
    return "UNKNOWN";
  }

  function getSecondsNeeded(quest, taskType) {
    const task = getTaskMap(quest)?.[taskType];
    if (!task) return 900;
    if (task.target != null) return task.target;          // v2: seconds / count
    if (task.secondsNeeded != null) return task.secondsNeeded; // v1 video
    if (task.minutesNeeded != null) return task.minutesNeeded * 60; // v1 play
    return 900;
  }

  function getApplicationId(quest, taskType) {
    const task = getTaskMap(quest)?.[taskType];
    if (task?.applications?.length > 0 && task.applications[0].id) return task.applications[0].id;
    if (task?.applicationId) return task.applicationId;
    if (quest.config?.application?.id) return quest.config.application.id;
    return quest.config?.contentId ?? null;
  }

  // ---------- Quest processors ----------
  const notifyUI = (state, progress, completed) => {
    sendUpdate('QUEST_UPDATE', {
      id: state.quest.id,
      name: state.questName,
      progress: Math.floor(progress),
      target: state.secondsNeeded,
      completed: completed,
      kind: state.taskType.startsWith('WATCH_VIDEO') ? 'video' : 'game'
    });
  };

  async function runVideoQuest(state, api) {
    const { quest, taskType, secondsNeeded, enrolledAt } = state;
    const maxFuture = 10;
    const speed = 6;
    const interval = 6;
    let secondsDone = state.currentProgress;
    let completed = false;
    let failCount = 0;


    while (true) {
      const maxAllowed = Math.floor((Date.now() - enrolledAt) / 1000) + maxFuture;
      const diff = maxAllowed - secondsDone;
      const timestamp = secondsDone + speed;

      if (diff >= speed) {
        try {
          const sendTimestamp = Math.min(secondsNeeded, timestamp + Math.random());
          const res = await api.post({ url: `/quests/${quest.id}/video-progress`, body: { timestamp: sendTimestamp } });

          completed = res.body?.completed_at != null;
          secondsDone = Math.min(secondsNeeded, timestamp);

          const apiProgress = res.body?.progress?.[taskType]?.value;
          if (typeof apiProgress === 'number') secondsDone = apiProgress;

          notifyUI(state, secondsDone, completed);
          failCount = 0;
        } catch (error) {
          if (++failCount >= 5) return; // unavailable quest — give up quietly
          await sleep(3000);
        }
      }

      if (timestamp >= secondsNeeded || completed) break;
      await sleep(interval * 1000);
    }

    // Final video-progress if not completed yet
    if (!completed) {
      try {
        const fin = await api.post({ url: `/quests/${quest.id}/video-progress`, body: { timestamp: secondsNeeded } });
        completed = fin.body?.completed_at != null;
      } catch (error) { /* ignore */ }
    }

    state.completed = true;
    notifyUI(state, secondsNeeded, true);
  }

  async function runHeartbeatQuest(state, api) {
    const { quest, taskType, secondsNeeded, appId } = state;
    const isActivity = taskType === 'PLAY_ACTIVITY';
    const body = isActivity
      ? { stream_key: 'call:1:1', terminal: false }
      : { application_id: appId, terminal: false };
    const terminalBody = isActivity
      ? { stream_key: 'call:1:1', terminal: true }
      : { application_id: appId, terminal: true };

    let elapsed = state.currentProgress;
    let completed = false;
    let failCount = 0;


    while (!completed) {
      try {
        const res = await api.post({ url: `/quests/${quest.id}/heartbeat`, body: body });

        const apiProgress = res.body?.progress?.[taskType]?.value;
        if (typeof apiProgress === 'number') {
          elapsed = apiProgress;
        } else {
          elapsed = Math.min(secondsNeeded, elapsed + HEARTBEAT_INTERVAL);
        }

        completed = res.body?.completed_at != null || elapsed >= secondsNeeded;
        notifyUI(state, elapsed, completed);
        failCount = 0;
        if (completed) break;
      } catch (error) {
        if (++failCount >= 5) return; // unavailable quest — give up quietly
        await sleep(5000);
      }
      await sleep(HEARTBEAT_INTERVAL * 1000);
    }

    // Terminal heartbeat
    try {
      await api.post({ url: `/quests/${quest.id}/heartbeat`, body: terminalBody });
    } catch (error) { /* ignore */ }

    state.completed = true;
    notifyUI(state, secondsNeeded, true);
  }

  async function runAchievementQuest(state, api) {
    const { quest, appId, secondsNeeded } = state;
    const questId = quest.id;


    // Step 1: OAuth2 authorize with the application
    const query = new URLSearchParams({
      response_type: 'code',
      client_id: appId,
      scope: 'identify applications.commands applications.entitlements',
      state: ''
    });
    let authCode = null;
    try {
      const authRes = await api.post({
        url: `/oauth2/authorize?${query.toString()}`,
        body: {
          permissions: '0',
          authorize: true,
          integration_type: 1,
          location_context: { guild_id: '10000', channel_id: '10000', channel_type: 10000 }
        }
      });
      const location = authRes.body?.location;
      if (location) {
        try {
          authCode = new URL(location).searchParams.get('code');
        } catch (e) {
          const m = String(location).match(/[?&]code=([^&]+)/);
          authCode = m ? m[1] : null;
        }
      }
    } catch (error) { /* ignore */ }

    if (!authCode) {
      return;
    }

    // Step 2: proxy ticket for the activity
    let ticket = null;
    try {
      const ticketRes = await api.post({ url: `/applications/${appId}/proxy-tickets`, body: {} });
      ticket = ticketRes.body?.ticket ?? null;
    } catch (error) { /* ignore */ }

    if (!ticket) {
      return;
    }

    const referrer = `https://${appId}.discordsays.com/?instance_id=example-cl-instance&platform=desktop&discord_proxy_ticket=${encodeURIComponent(ticket)}`;
    const baseHeaders = { 'Content-Type': 'application/json', 'X-Discord-Quest-ID': questId };

    // Step 3: authorize with Discord Says (cross-origin -> via background)
    const dsAuth = await dsFetch(
      `https://${appId}.discordsays.com/.proxy/acf/authorize`,
      Object.assign({}, baseHeaders, { 'X-Auth-Token': '' }),
      { code: authCode },
      referrer
    );
    const dsToken = dsAuth.body?.token;
    if (!dsToken) {
      return;
    }

    // Step 4: progress the achievement
    const dsProg = await dsFetch(
      `https://${appId}.discordsays.com/.proxy/acf/quest/progress`,
      Object.assign({}, baseHeaders, { 'X-Auth-Token': dsToken }),
      { progress: secondsNeeded },
      referrer
    );

    if (dsProg.ok) {
      state.completed = true;
      notifyUI(state, secondsNeeded, true);
    } else {
    }
  }

  // ---------- Main runner ----------
  async function runQuestCode(webpackRequire) {
    if (window.__QUEST_RUNNING) {
      console.info('Discord Auto Quest: already running, skipping duplicate start.');
      return;
    }
    window.__QUEST_RUNNING = true;

    try {
      const version = window.__QUEST_VERSION || 'unknown';
      if ('__QUEST_VERSION' in window) {
        try { delete window.__QUEST_VERSION; } catch (e) {}
      }
      console.info(`Discord Auto Quest: Initializing... (v${version})`);

      const stores = loadStores(webpackRequire);
      if (!stores) {
        sendUpdate('QUEST_ALL_DONE', { reason: 'no-stores' });
        return;
      }

      const activeQuests = getActiveQuests(stores.QuestsStore);
      if (activeQuests.length === 0) {
        console.info("Discord Auto Quest: You don't have any uncompleted active quests!");
        sendUpdate('QUEST_LIST', []);
        sendUpdate('QUEST_ALL_DONE', { reason: 'no-quests' });
        return;
      }

      const questStates = activeQuests.map(quest => initializeQuestState(quest)).filter(s => s !== null);

      sendUpdate('QUEST_LIST', questStates.map(state => ({
        id: state.quest.id,
        name: state.questName,
        progress: Math.floor(state.currentProgress),
        target: state.secondsNeeded,
        completed: state.completed,
        kind: state.taskType.startsWith('WATCH_VIDEO') ? 'video' : 'game'
      })));

      // Auto-enroll quests not enrolled yet (video quests etc.)
      for (const state of questStates) {
        if (!state.quest.userStatus?.enrolledAt && !state.completed) {
          await enrollQuest(state, stores.api);
        }
      }

      // All quests in parallel (aiko-style Promise.allSettled)
      await Promise.allSettled(
        questStates
          .filter(state => !state.completed)
          .map(state => runQuestByType(state, stores.api))
      );

      sendUpdate('QUEST_ALL_DONE', { reason: 'finished' });
    } catch (error) {
      sendUpdate('QUEST_ALL_DONE', { reason: 'error' });
    } finally {
      window.__QUEST_RUNNING = false;
    }
  }

  async function enrollQuest(state, api) {
    // POST /quests/<id>/enroll {"location":11,"is_targeted":false,"metadata_raw":null}
    try {
      const res = await api.post({
        url: `/quests/${state.quest.id}/enroll`,
        body: { location: 11, is_targeted: false, metadata_raw: null }
      });
      const body = res?.body ?? res;
      const enrolledAt = body?.enrolledAt ?? body?.user_status?.enrolledAt ?? body?.userStatus?.enrolledAt ?? null;
      if (!state.quest.userStatus) state.quest.userStatus = {};
      if (enrolledAt) {
        state.quest.userStatus.enrolledAt = enrolledAt;
        state.enrolledAt = new Date(enrolledAt).getTime();
      }
    } catch (error) {
      // not available to this account — stays at 0% but still shows in the list
    }
  }

  function runQuestByType(state, api) {
    if (state.taskType.startsWith('WATCH_VIDEO')) return runVideoQuest(state, api);
    if (state.taskType === 'PLAY_ACTIVITY') return runHeartbeatQuest(state, api);
    if (state.taskType === 'ACHIEVEMENT_IN_ACTIVITY') return runAchievementQuest(state, api);
    if (state.taskType === 'PLAY_ON_DESKTOP' || state.taskType === 'PLAY_ON_XBOX' || state.taskType === 'PLAY_ON_PLAYSTATION') {
      return runHeartbeatQuest(state, api);
    }
    return Promise.resolve();
  }

  function getActiveQuests(QuestsStore) {
    return [...QuestsStore.quests.values()].filter(quest => {
      const isExpired = new Date(quest.config.expiresAt).getTime() <= Date.now();
      const isCompleted = !!quest.userStatus?.completedAt;
      const taskMap = getTaskMap(quest);
      const hasSupportedTask = !!taskMap && QUEST_TYPES.some(type => taskMap[type] != null);

      // NOT-yet-enrolled quests stay too (auto-enrolled in runQuestCode)
      return !isCompleted && !isExpired && hasSupportedTask;
    });
  }

  function initializeQuestState(quest) {
    const taskType = getQuestType(quest);
    if (taskType === 'UNKNOWN') return null;

    const secondsNeeded = getSecondsNeeded(quest, taskType);
    const currentProgress = quest.userStatus?.progress?.[taskType]?.value ?? 0;
    const isVideo = taskType.startsWith('WATCH_VIDEO') || taskType === 'STREAM_ON_DESKTOP';
    const effectiveProgress = isVideo
      ? (currentProgress || quest.userStatus?.streamProgressSeconds || 0)
      : currentProgress;

    return {
      quest: quest,
      taskType: taskType,
      appId: getApplicationId(quest, taskType),
      secondsNeeded: secondsNeeded,
      currentProgress: effectiveProgress,
      completed: quest.userStatus?.completedAt != null,
      enrolledAt: quest.userStatus?.enrolledAt ? new Date(quest.userStatus.enrolledAt).getTime() : Date.now(),
      questName: quest.config?.messages?.questName ?? quest.config?.messages?.gameTitle ?? quest.id
    };
  }

  function loadStores(webpackRequire) {
    try {
      const QuestsStore = findModule(webpackRequire, m => m.__proto__?.getQuest);
      const api = findModule(webpackRequire, m => m.Bo?.get || m.tn?.get);

      if (!QuestsStore || !api) return null;

      return { QuestsStore: QuestsStore, api: api.Bo || api.tn || api };
    } catch (error) {
      return null;
    }
  }

  waitForWebpack(runQuestCode);
})();
